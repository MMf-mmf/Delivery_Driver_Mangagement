console.log('Javascript Enabled')
// func to make htmx work with the draggable library
htmx.onLoad(function (content) {
	var sortables = content.querySelectorAll('.sortable')
	for (var i = 0; i < sortables.length; i++) {
		var sortable = sortables[i]
		new Sortable(sortable, {
			animation: 150,
			ghostClass: 'blue-background-class',
		})
	}
})

// Initialize and add the map
function initMap() {
	// The location of Uluru
	const uluru = { lat: -25.344, lng: 131.031 }
	// The map, centered at Uluru
	const map = new google.maps.Map(document.getElementById('map'), {
		zoom: 4,
		center: uluru,
	})
	// The marker, positioned at Uluru
	const marker = new google.maps.Marker({
		position: uluru,
		map: map,
	})
}

window.initMap = initMap
